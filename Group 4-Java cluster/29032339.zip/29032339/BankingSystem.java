import java.sql.*;
import java.util.Scanner;

public class BankingSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AccountManager accountManager = new AccountManager();
        TransactionManager transactionManager = new TransactionManager();
        CustomerManager customerManager = new CustomerManager();
        while (true) {
            System.out.println("Main Menu:");
            System.out.println("1. Account Manager");
            System.out.println("2. Customer Manager");
            System.out.println("3. Transaction Manager");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    accountManagerMenu(scanner, accountManager);
                    break;
                case 2:
                    customerManagerMenu(scanner, customerManager);
                    break;
                case 3:
                    transactionManagerMenu(scanner, transactionManager);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void accountManagerMenu(Scanner scanner, AccountManager accountManager) {
        while (true) {
            System.out.println("Account Manager Menu:");
            System.out.println("1. Create Account");
            System.out.println("2. View Account Details");
            System.out.println("3. Update Account");
            System.out.println("4. Close Account");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter customer ID: ");
                        int customerId = scanner.nextInt();
                        System.out.print("Enter initial deposit: ");
                        double deposit = scanner.nextDouble();
                        System.out.print("Enter account type (savings/checking): ");
                        String type = scanner.next();
                        accountManager.createAccount(customerId, deposit, type);
                        break;
                    case 2:
                        accountManager.viewAccountDetails();
                        break;
                    case 3:
                        System.out.print("Enter account number: ");
                        int accNum = scanner.nextInt();
                        System.out.print("Enter new balance: ");
                        double balance = scanner.nextDouble();
                        System.out.print("Enter new account type: ");
                        String accType = scanner.next();
                        accountManager.updateAccount(accNum, balance, accType);
                        break;
                    case 4:
                        System.out.print("Enter account number: ");
                        int accNo = scanner.nextInt();
                        accountManager.closeAccount(accNo);
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.out.println("Error: " + "SQL ERROR CHECK FOR THE PATH");
            }
        }
    }

    private static void customerManagerMenu(Scanner scanner, CustomerManager customerManager) {
        while (true) {
            System.out.println("Customer Manager Menu:");
            System.out.println("1. Create Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Update Customer Details");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter name: ");
                        String name = scanner.next();
                        System.out.print("Enter email: ");
                        String email = scanner.next();
                        System.out.print("Enter phone number: ");
                        String phoneNumber = scanner.next();
                        System.out.print("Enter address: ");
                        String address = scanner.next();
                        customerManager.createCustomer(name, email, phoneNumber, address);
                        break;
                    case 2:
                        customerManager.viewCustomerDetails();
                        break;
                    case 3:
                        System.out.print("Enter customer ID: ");
                        int customerId = scanner.nextInt();
                        System.out.print("Enter new name: ");
                        String newName = scanner.next();
                        System.out.print("Enter new email: ");
                        String newEmail = scanner.next();
                        System.out.print("Enter new phone number: ");
                        String newPhoneNumber = scanner.next();
                        System.out.print("Enter new address: ");
                        String newAddress = scanner.next();
                        customerManager.updateCustomerDetails(customerId, newName, newEmail, newPhoneNumber, newAddress);
                        break;
                    case 4:
                        System.out.print("Enter customer ID: ");
                        int deleteCustomerId = scanner.nextInt();
                        customerManager.deleteCustomer(deleteCustomerId);
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void transactionManagerMenu(Scanner scanner, TransactionManager transactionManager) {
        while (true) {
            System.out.println("Transaction Manager Menu:");
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Transfer");
            System.out.println("4. View Transaction History");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter account number: ");
                        int depositAccNum = scanner.nextInt();
                        System.out.print("Enter amount: ");
                        double depositAmount = scanner.nextDouble();
                        transactionManager.deposit(depositAccNum, depositAmount);
                        break;
                    case 2:
                        System.out.print("Enter account number: ");
                        int withdrawAccNum = scanner.nextInt();
                        System.out.print("Enter amount: ");
                        double withdrawAmount = scanner.nextDouble();
                        transactionManager.withdraw(withdrawAccNum, withdrawAmount);
                        break;
                    case 3:
                        System.out.print("Enter from account number: ");
                        int fromAccNum = scanner.nextInt();
                        System.out.print("Enter to account number: ");
                        int toAccNum = scanner.nextInt();
                        System.out.print("Enter amount: ");
                        double transferAmount = scanner.nextDouble();
                        transactionManager.transfer(fromAccNum, toAccNum, transferAmount);
                        break;
                    case 4:
                        System.out.print("Enter account number: ");
                        int historyAccNum = scanner.nextInt();
                        transactionManager.viewTransactionHistory(historyAccNum);
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}