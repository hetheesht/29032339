import java.sql.*;
import java.util.*;

public class AccountManager {
    public void createAccount(int customerId, double initialDeposit, String type) throws SQLException {
        if (isCustomerExist(customerId)) {
            String accountQuery = "INSERT INTO Account (customer_id, balance, type) VALUES (?, ?, ?)";
            try (Connection connection = DatabaseConnection.getConnection();
                 PreparedStatement accountStatement = connection.prepareStatement(accountQuery, Statement.RETURN_GENERATED_KEYS)) {
                accountStatement.setInt(1, customerId);
                accountStatement.setDouble(2, initialDeposit);
                accountStatement.setString(3, type);
                accountStatement.executeUpdate();
                ResultSet rs = accountStatement.getGeneratedKeys();
                if (rs.next()) {
                    int accountNumber = rs.getInt(1);
                    System.out.println("Account created successfully. Account Number: " + accountNumber);
                }
            }
        } else {
            System.out.println("Customer with ID " + customerId + " does not exist.");
        }
    }
    private boolean isCustomerExist(int customerId) throws SQLException {
        String query = "SELECT customer_id FROM Customer WHERE customer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, customerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }
    public void viewAccountDetails() throws SQLException {
        String query = "SELECT Account.account_number, Account.customer_id, Customer.name, Customer.email, Customer.phone_number, Customer.address, Account.balance, Account.type FROM Account INNER JOIN Customer ON Account.customer_id = Customer.customer_id";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                System.out.println("Account Number: " + resultSet.getInt("account_number"));
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Phone Number: " + resultSet.getString("phone_number"));
                System.out.println("Address: " + resultSet.getString("address"));
                System.out.println("Balance: " + resultSet.getDouble("balance"));
                System.out.println("Type: " + resultSet.getString("type"));
                System.out.println("------");
            }
        }
    }
    public void updateAccount(int accountNumber, double newBalance, String newType) throws SQLException {
        String query = "UPDATE Account SET balance = ?, type = ? WHERE account_number = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setDouble(1, newBalance);
            statement.setString(2, newType);
            statement.setInt(3, accountNumber);
            statement.executeUpdate();
        }
    }
    public void closeAccount(int accountNumber) throws SQLException {
        String query = "DELETE FROM Account WHERE account_number = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, accountNumber);
            statement.executeUpdate();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AccountManager accountManager = new AccountManager();

        while (true) {
            System.out.println("Banking System Menu:");
            System.out.println("1. Create Account");
            System.out.println("2. View Account Details");
            System.out.println("3. Update Account");
            System.out.println("4. Close Account");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter customer ID: ");
                        int customerId = scanner.nextInt();
                        System.out.print("Enter initial deposit: ");
                        double deposit = scanner.nextDouble();
                        System.out.print("Enter account type (savings/checking): ");
                        String type = scanner.next();
                        accountManager.createAccount(customerId, deposit, type);
                        break;
                    case 2:
                        accountManager.viewAccountDetails();
                        break;
                    case 3:
                        System.out.print("Enter account number: ");
                        int accNum = scanner.nextInt();
                        System.out.print("Enter new balance: ");
                        double balance = scanner.nextDouble();
                        System.out.print("Enter new account type: ");
                        String accType = scanner.next();
                        accountManager.updateAccount(accNum, balance, accType);
                        break;
                    case 4:
                        System.out.print("Enter account number: ");
                        int accNo = scanner.nextInt();
                        accountManager.closeAccount(accNo);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.out.println("Error: " + "SQL ERROR");
            }
        }
    }
}
