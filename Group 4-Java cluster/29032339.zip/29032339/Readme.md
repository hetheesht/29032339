JDBC Connectivity 
-----------------
1. Search for "MySQL Download" in google and  then click on the first link 
2. Then search for " MySQL Community(GPL) Downloads " in the bottom of the page 
3. Select Connector/J and then select platform independent and download related to version
4. A zip file will be downloaded from that extract the .jar file
5. Go to the project say "CASE_STUDY" right click on the name and select build path
6. Then select "Add External JARs" and then select and upload the extracted jar file


DATABASE CREATION(Banking.sql)
-----------------------------
1. Go to the project and then click on "window" on the top 
2. Select perspective->Open perspective->other, then Database Management
3. If you don't find Database Management then select help from the top and then select "Install New Software". In work with select "Latest Eclipse Simultaneous Release" and then select Database Development and click Next and then finish. Restart the eclipse to see the updates. Now repeat step 2
4. After selecting Database Development, Right click on the folder Database Connections and select new which a prompt will be appeared to select the Connection profile type, select MySQL and then select the driver template in name/type and in jar list select the extracted jar list. Give name for the database say "Banking" and give password in the database and then click in finish.
5. Now check the Database Connection you can find the "Banking" database where you can create the tables Customer, Account and Transaction as shown in "Banking.sql".
6. Now the tables are created.

Account Management
------------------
The Account Management methods are handled in AccountManager.java, they are "Create a new account" method which is used to create a new account for the customer by creating a recording in the account table, "View account details" method which retrieves all records from Account table, "Update account information" method which updates the record in Account table by taking inputs Account number, balance and account type, "Close an account" method deletes a record from the Account table by taking input account number.

Transaction Management
----------------------
The Transaction Management methods are handled in TransactionManager.java. These include the "deposit" method to add funds to an account and record the transaction, the "withdraw" method to subtract funds if sufficient balance exists and record the transaction, the "transfer" method to move funds between accounts with balance checks and transaction recording, and the "viewTransactionHistory" method to retrieve and display all transactions for a specified account. These methods ensure all transactions are accurately recorded and the account balances are updated accordingly.

Customer Management
-------------------
The Customer Management methods are handled in CustomerManager.java. These include the "createCustomer" method to add a new customer to the database, the "viewCustomerDetails" method to retrieve and display all customer records, the "updateCustomerDetails" method to update customer information based on their ID, and the "deleteCustomer" method to remove a customer from the database using their ID. These methods ensure that customer data is accurately managed, providing functionalities to create, view, update, and delete customer records.

Banking System
--------------
The BankingSystem class provides a main page to manage accounts, customers, and transactions using the respective manager classes: AccountManager, CustomerManager, and TransactionManager. The main menu allows users to navigate between account management, customer management, and transaction management. Each manager has its own submenu for specific operations. The AccountManager handles creating new accounts, viewing account details, updating account information, and closing accounts. The CustomerManager allows for creating new customers, viewing customer details, updating customer information, and deleting customers. The TransactionManager manages deposits, withdrawals, transfers, and viewing transaction history. The program uses JDBC for database interactions and handles exceptions to ensure smooth operation.