import java.sql.*;
import java.util.*;

public class TransactionManager {

    public void deposit(int accountNumber, double amount) throws SQLException {
        String updateBalanceQuery = "UPDATE Account SET balance = balance + ? WHERE account_number = ?";
        String insertTransactionQuery = "INSERT INTO Transaction (account_number, transaction_type, amount) VALUES (?, 'deposit', ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement updateBalanceStatement = connection.prepareStatement(updateBalanceQuery);
             PreparedStatement insertTransactionStatement = connection.prepareStatement(insertTransactionQuery)) {

            // Update account balance
            updateBalanceStatement.setDouble(1, amount);
            updateBalanceStatement.setInt(2, accountNumber);
            updateBalanceStatement.executeUpdate();

            // Insert transaction record
            insertTransactionStatement.setInt(1, accountNumber);
            insertTransactionStatement.setDouble(2, amount);
            insertTransactionStatement.executeUpdate();

            System.out.println("Deposit successful.");
        }
    }

    public void withdraw(int accountNumber, double amount) throws SQLException {
        String checkBalanceQuery = "SELECT balance FROM Account WHERE account_number = ?";
        String updateBalanceQuery = "UPDATE Account SET balance = balance - ? WHERE account_number = ?";
        String insertTransactionQuery = "INSERT INTO Transaction (account_number, transaction_type, amount) VALUES (?, 'withdrawal', ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement checkBalanceStatement = connection.prepareStatement(checkBalanceQuery);
             PreparedStatement updateBalanceStatement = connection.prepareStatement(updateBalanceQuery);
             PreparedStatement insertTransactionStatement = connection.prepareStatement(insertTransactionQuery)) {

            // Check if sufficient balance exists
            checkBalanceStatement.setInt(1, accountNumber);
            ResultSet rs = checkBalanceStatement.executeQuery();
            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance < amount) {
                    System.out.println("Insufficient funds.");
                    return;
                }
            }

            // Update account balance
            updateBalanceStatement.setDouble(1, amount);
            updateBalanceStatement.setInt(2, accountNumber);
            updateBalanceStatement.executeUpdate();

            // Insert transaction record
            insertTransactionStatement.setInt(1, accountNumber);
            insertTransactionStatement.setDouble(2, amount);
            insertTransactionStatement.executeUpdate();

            System.out.println("Withdrawal successful.");
        }
    }

    public void transfer(int fromAccountNumber, int toAccountNumber, double amount) throws SQLException {
        String checkBalanceQuery = "SELECT balance FROM Account WHERE account_number = ?";
        String updateFromAccountQuery = "UPDATE Account SET balance = balance - ? WHERE account_number = ?";
        String updateToAccountQuery = "UPDATE Account SET balance = balance + ? WHERE account_number = ?";
        String insertTransactionQuery = "INSERT INTO Transaction (account_number, transaction_type, amount) VALUES (?, 'transfer', ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement checkBalanceStatement = connection.prepareStatement(checkBalanceQuery);
             PreparedStatement updateFromAccountStatement = connection.prepareStatement(updateFromAccountQuery);
             PreparedStatement updateToAccountStatement = connection.prepareStatement(updateToAccountQuery);
             PreparedStatement insertTransactionStatement = connection.prepareStatement(insertTransactionQuery)) {

            // Check if sufficient balance exists in fromAccount
            checkBalanceStatement.setInt(1, fromAccountNumber);
            ResultSet rs = checkBalanceStatement.executeQuery();
            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance < amount) {
                    System.out.println("Insufficient funds.");
                    return;
                }
            }

            // Begin transaction
            connection.setAutoCommit(false);

            try {
                // Deduct from fromAccount
                updateFromAccountStatement.setDouble(1, amount);
                updateFromAccountStatement.setInt(2, fromAccountNumber);
                updateFromAccountStatement.executeUpdate();

                // Add to toAccount
                updateToAccountStatement.setDouble(1, amount);
                updateToAccountStatement.setInt(2, toAccountNumber);
                updateToAccountStatement.executeUpdate();

                // Insert transaction record for fromAccount
                insertTransactionStatement.setInt(1, fromAccountNumber);
                insertTransactionStatement.setDouble(2, amount);
                insertTransactionStatement.executeUpdate();

                // Insert transaction record for toAccount
                insertTransactionStatement.setInt(1, toAccountNumber);
                insertTransactionStatement.setDouble(2, amount);
                insertTransactionStatement.executeUpdate();

                // Commit transaction
                connection.commit();
                System.out.println("Transfer successful.");
            } catch (SQLException e) {
                connection.rollback();
                System.out.println("Transfer failed. Transaction rolled back.");
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public void viewTransactionHistory(int accountNumber) throws SQLException {
        String query = "SELECT * FROM Transaction WHERE account_number = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, accountNumber);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Account Number: " + rs.getInt("account_number"));
                System.out.println("Transaction Type: " + rs.getString("transaction_type"));
                System.out.println("Amount: " + rs.getDouble("amount"));
                System.out.println("Transaction Date: " + rs.getTimestamp("transaction_date"));
                System.out.println("------");
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TransactionManager transactionManager = new TransactionManager();

        while (true) {
            System.out.println("Transaction Menu:");
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Transfer");
            System.out.println("4. View Transaction History");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter account number: ");
                        int depositAccNum = scanner.nextInt();
                        System.out.print("Enter amount: ");
                        double depositAmount = scanner.nextDouble();
                        transactionManager.deposit(depositAccNum, depositAmount);
                        break;
                    case 2:
                        System.out.print("Enter account number: ");
                        int withdrawAccNum = scanner.nextInt();
                        System.out.print("Enter amount: ");
                        double withdrawAmount = scanner.nextDouble();
                        transactionManager.withdraw(withdrawAccNum, withdrawAmount);
                        break;
                    case 3:
                        System.out.print("Enter from account number: ");
                        int fromAccNum = scanner.nextInt();
                        System.out.print("Enter to account number: ");
                        int toAccNum = scanner.nextInt();
                        System.out.print("Enter amount: ");
                        double transferAmount = scanner.nextDouble();
                        transactionManager.transfer(fromAccNum, toAccNum, transferAmount);
                        break;
                    case 4:
                        System.out.print("Enter account number: ");
                        int historyAccNum = scanner.nextInt();
                        transactionManager.viewTransactionHistory(historyAccNum);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.out.println("Error: " + "SQL ERROR");
            }
        }
    }
}
