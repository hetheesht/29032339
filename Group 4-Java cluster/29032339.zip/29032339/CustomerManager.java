import java.sql.*;
import java.util.Scanner;

public class CustomerManager {
    public void createCustomer(String name, String email, String phoneNumber, String address) throws SQLException {
        String customerQuery = "INSERT INTO Customer (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement customerStatement = connection.prepareStatement(customerQuery, Statement.RETURN_GENERATED_KEYS)) {
            customerStatement.setString(1, name);
            customerStatement.setString(2, email);
            customerStatement.setString(3, phoneNumber);
            customerStatement.setString(4, address);
            customerStatement.executeUpdate();
            ResultSet rs = customerStatement.getGeneratedKeys();
            if (rs.next()) {
                int customerId = rs.getInt(1);
                System.out.println("Customer created successfully. Customer ID: " + customerId);
            }
        }
    }
    public void viewCustomerDetails() throws SQLException {
        String query = "SELECT * FROM Customer";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Phone Number: " + resultSet.getString("phone_number"));
                System.out.println("Address: " + resultSet.getString("address"));
                System.out.println("------");
            }
        }
    }
    public void updateCustomerDetails(int customerId, String name, String email, String phoneNumber, String address) throws SQLException {
        String query = "UPDATE Customer SET name = ?, email = ?, phone_number = ?, address = ? WHERE customer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phoneNumber);
            statement.setString(4, address);
            statement.setInt(5, customerId);
            statement.executeUpdate();
            System.out.println("Customer details updated successfully.");
        }
    }
    public void deleteCustomer(int customerId) throws SQLException {
        String query = "DELETE FROM Customer WHERE customer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, customerId);
            statement.executeUpdate();
            System.out.println("Customer deleted successfully.");
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CustomerManager customerManager = new CustomerManager();
        while (true) {
            System.out.println("Customer Management Menu:");
            System.out.println("1. Create Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Update Customer Details");
            System.out.println("4. Delete Customer");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter name: ");
                        String name = scanner.next();
                        System.out.print("Enter email: ");
                        String email = scanner.next();
                        System.out.print("Enter phone number: ");
                        String phoneNumber = scanner.next();
                        System.out.print("Enter address: ");
                        String address = scanner.next();
                        customerManager.createCustomer(name, email, phoneNumber, address);
                        break;
                    case 2:
                        customerManager.viewCustomerDetails();
                        break;
                    case 3:
                        System.out.print("Enter customer ID: ");
                        int customerId = scanner.nextInt();
                        System.out.print("Enter new name: ");
                        String newName = scanner.next();
                        System.out.print("Enter new email: ");
                        String newEmail = scanner.next();
                        System.out.print("Enter new phone number: ");
                        String newPhoneNumber = scanner.next();
                        System.out.print("Enter new address: ");
                        String newAddress = scanner.next();
                        customerManager.updateCustomerDetails(customerId, newName, newEmail, newPhoneNumber, newAddress);
                        break;
                    case 4:
                        System.out.print("Enter customer ID: ");
                        int deleteCustomerId = scanner.nextInt();
                        customerManager.deleteCustomer(deleteCustomerId);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.out.println("Error: " + "SQL ERROR");
            }
        }
    }
}
